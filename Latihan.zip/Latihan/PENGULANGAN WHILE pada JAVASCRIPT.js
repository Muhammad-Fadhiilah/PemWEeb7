var nilaiAwal = 1;
while(nilaiAwal <= 1000){
	console.log('Hello world!');
nilaiAwal++;
}