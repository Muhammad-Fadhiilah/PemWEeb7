var ulang = true;
while(ulang){
	console.log('Hello World!');
	ulang = confirm('lagi?');
}