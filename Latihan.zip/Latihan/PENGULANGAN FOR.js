var jmlAngkot = 10;
var angkotBerperasi = 6;
var noAngkot = 1;

while(noAngkot <= angkotBerperasi){
	console.log('Angkot No. ' + noAngkot + 'beroperasi dengan baik.');
	
	noAngkot++;
}

for(noAngkot = 7; noAngkot<= jmlAngkot; noAngkot++){
	console.log('Angkot No. ' + noAngkot + 'sedang tidak beroperasi');
}