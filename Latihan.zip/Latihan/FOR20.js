for(var nilaiAwal = l; nilaiAwal <= 10; nilaiAwal++ ) {
	console.log('Hello World!');
}