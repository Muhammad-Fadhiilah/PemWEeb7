var angka = prompt('Masukan angka');
if(angka %2 ===0 ){
	alert(angka + 'adalah bilangan GENAP');
}else {
	alert(angka + 'adalah bilangan GANJIL');
}