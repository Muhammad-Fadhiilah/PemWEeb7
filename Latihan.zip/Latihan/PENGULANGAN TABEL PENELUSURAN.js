var nilaiAwal = 1;
while (nilaiAwal <= 10_ {
	console.log('Angkot No.' + nilaiAwal + 'beroperasi dengan baik.');
nilaiAwal++;
}